<?php


namespace JustForFun\Portal\Pub\Controller;

use JustForFun\Portal\ServerStatus\StatusRetriever;
use XF\Pub\Controller\AbstractController;

class Server extends AbstractController
{

    public function actionIndex()
    {
        $viewParams = array("servers" => array());

        $finder = \XF::finder("JustForFun\Portal:Cache_Servers");
        $servers_cache = $finder->where("date", ">", time() - 240)->fetch();

        $servers = explode(";", $this->options()->server_list);

        if(count($servers_cache) != count($servers)) {
            foreach ($servers as $server) {
                $server_expl = explode(":", $server);

                unset($server_cache);
                $finder = \XF::finder("JustForFun\Portal:Cache_Servers");
                $server_cache = $finder->where("ip", "=", $server)->fetch();

                if (count($server_cache) == 0) {
                    $server_cache = \XF::em()->create("JustForFun\Portal:Cache_Servers");
                    $server_cache->set("ip", $server);
                } else {
                    $server_cache = $server_cache->first();
                }

                $json = json_encode(StatusRetriever::get($server_expl[0], (int)$server_expl[1])->toArray());
                $server_cache->set("data", $json);
                $server_cache->set("date", time());

                $server_cache->save(false);
            }

            unset($servers_cache);
            $finder = \XF::finder("JustForFun\Portal:Cache_Servers");
            $servers_cache = $finder->where("date", ">", time() - 240)->fetch();
        }

        foreach ($servers_cache as $cache) {
            $data = json_decode($cache->get("data"), true);
            $data["lastupdate"] = $cache->get("date");
            $viewParams["servers"][] = $data;
        }

        return $this->view("JustForFun\ServerRestart:View", "justforfun_server_restart_view", $viewParams);
    }
}